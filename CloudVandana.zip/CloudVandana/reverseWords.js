//A. Take a sentence as an input and reverse every word in that sentence.Example - This is a sunny day > shiT si a ynnus yad

function reverseWords(sentence) {
    let reversedSentence = "";
    let word = "";
    
    for (let i = 0; i < sentence.length; i++) {
        if (sentence[i] !== " " && i !== sentence.length - 1) {
            word += sentence[i];
        } else {
            if (i === sentence.length - 1) {
                word += sentence[i];
            }

            let reversedWord = "";
            for (let j = word.length - 1; j >= 0; j--) {
                reversedWord += word[j];
            }
            reversedSentence += reversedWord;
            if (i !== sentence.length - 1) {
                reversedSentence += " ";
            }
            word = "";
        }
    }
    return reversedSentence;
}

let inputSentence = "This is a sunny day";
let reversedSentence = reverseWords(inputSentence);
console.log(reversedSentence); 