//B. Perform sorting of an array in descending order

function sortDescending(arr) {
    let len = arr.length;
    for (let i = 0; i < len - 1; i++) {
        let maxIndex = i;
        for (let j = i + 1; j < len; j++) {
            if (arr[j] > arr[maxIndex]) {
                maxIndex = j;
            }
        }
        let temp = arr[i];
        arr[i] = arr[maxIndex];
        arr[maxIndex] = temp;
    }
    return arr;
}


let numbers = [5, 2, 9, 1, 5, 6];
let sortedArray = sortDescending(numbers);
console.log(sortedArray); 