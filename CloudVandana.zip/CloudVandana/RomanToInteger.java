// B. Enter a Roman Number as input and convert it to an integer.(ex IX = 9) 

import java.util.*;


public class RomanToInteger {
    public static int romanToInt(String s) {
        HashMap<Character, Integer> romanToIntMap = new HashMap<>();
        romanToIntMap.put('I', 1);
        romanToIntMap.put('V', 5);
        romanToIntMap.put('X', 10);
        romanToIntMap.put('L', 50);
        romanToIntMap.put('C', 100);
        romanToIntMap.put('D', 500);
        romanToIntMap.put('M', 1000);

        int result = 0;
        int prevValue = 0;

        for (int i = s.length() - 1; i >= 0; i--) {
            char currentSymbol = s.charAt(i);
            int currentValue = romanToIntMap.get(currentSymbol);

            if (currentValue < prevValue) {
                result -= currentValue;
            } else {
                result += currentValue;
            }
            prevValue = currentValue;
        }

        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a Roman numeral: ");
        String romanNumeral = sc.nextLine();
        int integerEquivalent = romanToInt(romanNumeral.toUpperCase()); 

       
        System.out.println("Integer equivalent: " + integerEquivalent);

        
}
}
