// C. Check if the input is pangram or not.(Pangram is a sentence that contains all the alphabetrom a-z) 

import java.util.Scanner;

public class PangramChecker {
    public static boolean isPangram(String input) {
		
        boolean[] alphabetPresent = new boolean[26];
        
        for (char ch : input.toLowerCase().toCharArray()) {
            if (Character.isLetter(ch)) {
                int index = ch - 'a';
                alphabetPresent[index] = true;
            }
        }
        
        for (boolean letterPresent : alphabetPresent) {
            if (!letterPresent) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a sentence: ");
        String input = sc.nextLine();

        boolean result = isPangram(input);

        if (result) {
            System.out.println("The input is a pangram.");
        } else {
            System.out.println("The input is not a pangram.");
        }

        
      }
}
